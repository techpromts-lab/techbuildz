"use client";

import { useState } from "react";
import { useAppStore } from "@/lib/store";
import {
  Settings,
  Github,
  Code2,
  Eye,
  Columns,
  MessageSquare,
  Terminal,
  Download,
} from "lucide-react";
import SettingsPanel from "./SettingsPanel";
import { AnimatePresence } from "framer-motion";

export default function Toolbar() {
  const {
    viewMode,
    setViewMode,
    showChat,
    setShowChat,
    showSettings,
    setShowSettings,
    showTerminal,
    setShowTerminal,
    files,
  } = useAppStore();

  const [exporting, setExporting] = useState(false);
  const [githubUrl, setGithubUrl] = useState("");

  const handleExportGithub = async () => {
    const repoName = prompt("اسم الريبو على GitHub:", "techbuildz-project");
    if (!repoName) return;

    setExporting(true);
    try {
      const res = await fetch("/api/github", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          files,
          repoName,
          description: "Created with techbuildz by techpromts",
          isPrivate: false,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setGithubUrl(data.url);
        alert(`تم التصدير بنجاح!\n${data.url}`);
      } else {
        alert(data.error || "فشل التصدير");
      }
    } catch (err) {
      alert("حصل خطأ أثناء التصدير");
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="h-12 border-b border-border bg-card/80 backdrop-blur flex items-center justify-between px-4 relative">
      {/* Left */}
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-2 mr-4">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
            <Code2 className="w-4 h-4 text-white" />
          </div>
          <span className="font-semibold text-sm">
            tech<span className="text-primary">buildz</span>
          </span>
        </div>

        {/* View mode */}
        <div className="flex items-center bg-secondary rounded-lg p-0.5">
          <button
            onClick={() => setViewMode("code")}
            className={`p-1.5 rounded-md transition-colors ${
              viewMode === "code"
                ? "bg-primary text-white"
                : "text-muted-foreground hover:text-foreground"
            }`}
            title="Code only"
          >
            <Code2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode("split")}
            className={`p-1.5 rounded-md transition-colors ${
              viewMode === "split"
                ? "bg-primary text-white"
                : "text-muted-foreground hover:text-foreground"
            }`}
            title="Split view"
          >
            <Columns className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode("preview")}
            className={`p-1.5 rounded-md transition-colors ${
              viewMode === "preview"
                ? "bg-primary text-white"
                : "text-muted-foreground hover:text-foreground"
            }`}
            title="Preview only"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Right */}
      <div className="flex items-center gap-1">
        <button
          onClick={() => setShowChat(!showChat)}
          className={`p-2 rounded-lg transition-colors ${
            showChat
              ? "bg-primary/20 text-primary"
              : "text-muted-foreground hover:text-foreground hover:bg-card-hover"
          }`}
          title="Chat"
        >
          <MessageSquare className="w-4 h-4" />
        </button>

        <button
          onClick={() => setShowTerminal(!showTerminal)}
          className={`p-2 rounded-lg transition-colors ${
            showTerminal
              ? "bg-primary/20 text-primary"
              : "text-muted-foreground hover:text-foreground hover:bg-card-hover"
          }`}
          title="Terminal"
        >
          <Terminal className="w-4 h-4" />
        </button>

        <button
          onClick={handleExportGithub}
          disabled={exporting}
          className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-card-hover transition-colors disabled:opacity-50"
          title="Export to GitHub"
        >
          <Github className="w-4 h-4" />
        </button>

        <button
          onClick={() => setShowSettings(!showSettings)}
          className={`p-2 rounded-lg transition-colors ${
            showSettings
              ? "bg-primary/20 text-primary"
              : "text-muted-foreground hover:text-foreground hover:bg-card-hover"
          }`}
          title="Settings"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>

      <AnimatePresence>
        {showSettings && <SettingsPanel />}
      </AnimatePresence>
    </div>
  );
}
