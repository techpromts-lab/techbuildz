"use client";

import { useAppStore } from "@/lib/store";
import { ENVIRONMENTS, MODELS, Environment } from "@/lib/templates";
import { X, Check } from "lucide-react";
import { motion } from "framer-motion";

export default function SettingsPanel() {
  const {
    environment,
    model,
    setEnvironment,
    setModel,
    setShowSettings,
    resetProject,
  } = useAppStore();

  const handleEnvChange = (env: Environment) => {
    if (confirm("تغيير البيئة راح يعيد تعيين المشروع. متأكد؟")) {
      resetProject(env);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="absolute top-12 left-4 w-80 bg-card border border-border rounded-2xl shadow-2xl z-50 overflow-hidden"
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <h3 className="font-semibold">الإعدادات</h3>
        <button
          onClick={() => setShowSettings(false)}
          className="p-1 rounded-lg hover:bg-card-hover transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4 space-y-6">
        {/* Environment */}
        <div>
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 block">
            بيئة البرمجة
          </label>
          <div className="space-y-2">
            {ENVIRONMENTS.map((env) => (
              <button
                key={env.id}
                onClick={() => handleEnvChange(env.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border transition-all ${
                  environment === env.id
                    ? "border-primary bg-primary/10"
                    : "border-border hover:border-primary/30 hover:bg-card-hover"
                }`}
              >
                <span className="text-lg">{env.icon}</span>
                <div className="text-right flex-1">
                  <p className="text-sm font-medium">{env.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {env.description}
                  </p>
                </div>
                {environment === env.id && (
                  <Check className="w-4 h-4 text-primary" />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Model */}
        <div>
          <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3 block">
            نموذج الـ AI
          </label>
          <div className="space-y-1.5">
            {MODELS.map((m) => (
              <button
                key={m.id}
                onClick={() => setModel(m.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-all ${
                  model === m.id
                    ? "bg-primary/20 text-primary"
                    : "hover:bg-card-hover text-muted-foreground hover:text-foreground"
                }`}
              >
                <span>{m.name}</span>
                {model === m.id && <Check className="w-3.5 h-3.5" />}
              </button>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
