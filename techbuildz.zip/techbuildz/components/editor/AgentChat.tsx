"use client";

import { useState, useRef, useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { Send, Sparkles, Loader2, User, Bot } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function AgentChat() {
  const {
    messages,
    addMessage,
    isGenerating,
    setIsGenerating,
    model,
    files,
  } = useAppStore();

  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isGenerating]);

  const handleSend = async () => {
    if (!input.trim() || isGenerating) return;

    const userMessage = input.trim();
    setInput("");
    addMessage({ role: "user", content: userMessage });
    setIsGenerating(true);

    try {
      // Build context with current files (limited)
      const filesContext = Object.entries(files)
        .slice(0, 8)
        .map(([path, content]) => `--- ${path} ---\n${content.slice(0, 1500)}`)
        .join("\n\n");

      const contextualMessages = [
        {
          role: "user" as const,
          content: `الملفات الحالية في المشروع:\n\n${filesContext}\n\n---\n\nطلب المستخدم: ${userMessage}`,
        },
      ];

      const res = await fetch("/api/agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, ...contextualMessages],
          model,
        }),
      });

      const data = await res.json();

      if (data.error) {
        addMessage({
          role: "assistant",
          content: `خطأ: ${data.error}`,
        });
      } else {
        addMessage({ role: "assistant", content: data.reply });
      }
    } catch (err: any) {
      addMessage({
        role: "assistant",
        content: "حصل خطأ في الاتصال. جرب مرة ثانية.",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-card/30">
      {/* Header */}
      <div className="h-11 flex items-center gap-2 px-4 border-b border-border">
        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
        <div>
          <p className="text-sm font-medium">techpromts agent</p>
          <p className="text-[10px] text-muted-foreground">جاهز للمساعدة</p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="text-center text-muted-foreground text-sm mt-10">
            <Sparkles className="w-8 h-8 mx-auto mb-3 text-primary/50" />
            <p>مرحباً! أنا techpromts agent</p>
            <p className="mt-1">قولي شو تبي تبني وأنا بساعدك</p>
          </div>
        )}

        <AnimatePresence>
          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                  msg.role === "user"
                    ? "bg-secondary"
                    : "bg-gradient-to-br from-primary to-accent"
                }`}
              >
                {msg.role === "user" ? (
                  <User className="w-4 h-4" />
                ) : (
                  <Bot className="w-4 h-4 text-white" />
                )}
              </div>
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                  msg.role === "user"
                    ? "bg-primary/20 text-foreground"
                    : "bg-card border border-border"
                }`}
              >
                <pre className="whitespace-pre-wrap font-sans">{msg.content}</pre>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isGenerating && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-card border border-border rounded-2xl px-4 py-3">
              <Loader2 className="w-4 h-4 animate-spin text-primary" />
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="p-3 border-t border-border">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
            placeholder="اكتب طلبك هنا..."
            className="flex-1 bg-secondary border border-border rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-primary/50 transition-colors"
            disabled={isGenerating}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isGenerating}
            className="w-10 h-10 rounded-xl bg-primary hover:bg-primary-hover disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center transition-colors"
          >
            <Send className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}
