"use client";

import { useEffect, useRef, useState } from "react";
import { useAppStore } from "@/lib/store";
import { getWebContainer } from "@/lib/webcontainer";
import { Loader2, RefreshCw, ExternalLink } from "lucide-react";

export default function Preview() {
  const { files, environment } = useAppStore();
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [status, setStatus] = useState<"idle" | "booting" | "installing" | "starting" | "ready" | "error">("idle");
  const [errorMsg, setErrorMsg] = useState("");
  const [previewUrl, setPreviewUrl] = useState("");

  const startPreview = async () => {
    try {
      setStatus("booting");
      setErrorMsg("");

      const wc = await getWebContainer();

      // Clear previous files (simple approach)
      setStatus("installing");

      // Write all files
      for (const [path, content] of Object.entries(files)) {
        const parts = path.split("/");
        if (parts.length > 1) {
          await wc.fs.mkdir(parts.slice(0, -1).join("/"), { recursive: true });
        }
        await wc.fs.writeFile(path, content);
      }

      // Install dependencies if package.json exists
      if (files["package.json"]) {
        const installProcess = await wc.spawn("npm", ["install"]);
        const installExit = await installProcess.exit;
        if (installExit !== 0) {
          throw new Error("npm install failed");
        }
      }

      setStatus("starting");

      // Determine start command
      let command = "npm";
      let args = ["run", "dev"];

      if (environment === "html") {
        // For pure HTML we can use a simple static server or just open index
        // WebContainer can serve static with npx serve or similar
        args = ["exec", "serve", ".", "-p", "3000"];
      } else if (environment === "node") {
        args = ["run", "dev"];
      }

      const process = await wc.spawn(command, args);

      // Capture output
      process.output.pipeTo(
        new WritableStream({
          write(data) {
            console.log("[WC]", data);
          },
        })
      );

      wc.on("server-ready", (port, url) => {
        setPreviewUrl(url);
        if (iframeRef.current) {
          iframeRef.current.src = url;
        }
        setStatus("ready");
      });
    } catch (err: any) {
      console.error(err);
      setStatus("error");
      setErrorMsg(err.message || "Failed to start preview");
    }
  };

  useEffect(() => {
    // Auto start on mount
    startPreview();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="h-full w-full flex flex-col bg-[#0d0d12]">
      {/* Toolbar */}
      <div className="h-9 flex items-center justify-between px-3 border-b border-border bg-card/50">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          {status === "ready" ? (
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
              Preview جاهز
            </span>
          ) : status === "error" ? (
            <span className="text-danger">خطأ</span>
          ) : (
            <span className="flex items-center gap-1.5">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              {status === "booting" && "جاري التشغيل..."}
              {status === "installing" && "تثبيت الحزم..."}
              {status === "starting" && "تشغيل السيرفر..."}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={startPreview}
            className="p-1.5 rounded-md hover:bg-card-hover text-muted-foreground hover:text-foreground transition-colors"
            title="Refresh"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          {previewUrl && (
            <a
              href={previewUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 rounded-md hover:bg-card-hover text-muted-foreground hover:text-foreground transition-colors"
              title="Open in new tab"
            >
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 relative">
        {status === "error" ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6">
            <p className="text-danger mb-2">فشل تشغيل الـ Preview</p>
            <p className="text-sm text-muted-foreground mb-4">{errorMsg}</p>
            <button
              onClick={startPreview}
              className="px-4 py-2 bg-primary text-white rounded-lg text-sm hover:bg-primary-hover transition-colors"
            >
              إعادة المحاولة
            </button>
          </div>
        ) : status !== "ready" ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">
                {status === "booting" && "جاري تحميل WebContainer..."}
                {status === "installing" && "جاري تثبيت الـ packages..."}
                {status === "starting" && "جاري تشغيل المشروع..."}
              </p>
            </div>
          </div>
        ) : null}

        <iframe
          ref={iframeRef}
          className={`w-full h-full bg-white ${status !== "ready" ? "opacity-0" : "opacity-100"} transition-opacity`}
          sandbox="allow-scripts allow-same-origin allow-forms allow-modals allow-popups"
          title="Preview"
        />
      </div>
    </div>
  );
}
