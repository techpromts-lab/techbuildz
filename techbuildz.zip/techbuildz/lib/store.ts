import { create } from "zustand";
import { Environment, getInitialFiles } from "./templates";

export type FileMap = Record<string, string>;

interface AppState {
  // Project
  files: FileMap;
  activeFile: string;
  environment: Environment;
  model: string;

  // UI
  showPreview: boolean;
  showTerminal: boolean;
  showSettings: boolean;
  showChat: boolean;
  viewMode: "split" | "code" | "preview";

  // Chat
  messages: { role: "user" | "assistant"; content: string }[];
  isGenerating: boolean;

  // Actions
  setFiles: (files: FileMap) => void;
  updateFile: (path: string, content: string) => void;
  setActiveFile: (path: string) => void;
  setEnvironment: (env: Environment) => void;
  setModel: (model: string) => void;
  setShowPreview: (v: boolean) => void;
  setShowTerminal: (v: boolean) => void;
  setShowSettings: (v: boolean) => void;
  setShowChat: (v: boolean) => void;
  setViewMode: (mode: "split" | "code" | "preview") => void;
  addMessage: (msg: { role: "user" | "assistant"; content: string }) => void;
  setIsGenerating: (v: boolean) => void;
  resetProject: (env: Environment) => void;
}

export const useAppStore = create<AppState>((set) => ({
  files: getInitialFiles("nextjs"),
  activeFile: "app/page.tsx",
  environment: "nextjs",
  model: "llama-3.3-70b-versatile",

  showPreview: true,
  showTerminal: false,
  showSettings: false,
  showChat: true,
  viewMode: "split",

  messages: [],
  isGenerating: false,

  setFiles: (files) => set({ files }),
  updateFile: (path, content) =>
    set((state) => ({
      files: { ...state.files, [path]: content },
    })),
  setActiveFile: (path) => set({ activeFile: path }),
  setEnvironment: (env) => set({ environment: env }),
  setModel: (model) => set({ model }),
  setShowPreview: (v) => set({ showPreview: v }),
  setShowTerminal: (v) => set({ showTerminal: v }),
  setShowSettings: (v) => set({ showSettings: v }),
  setShowChat: (v) => set({ showChat: v }),
  setViewMode: (mode) => set({ viewMode: mode }),
  addMessage: (msg) =>
    set((state) => ({ messages: [...state.messages, msg] })),
  setIsGenerating: (v) => set({ isGenerating: v }),
  resetProject: (env) => {
    const files = getInitialFiles(env);
    const firstFile = Object.keys(files)[0];
    set({
      environment: env,
      files,
      activeFile: firstFile,
      messages: [],
    });
  },
}));
