import Groq from "groq-sdk";

const keys = [
  process.env.GROQ_API_KEY_1,
  process.env.GROQ_API_KEY_2,
  process.env.GROQ_API_KEY_3,
  process.env.GROQ_API_KEY_4,
  process.env.GROQ_API_KEY_5,
].filter(Boolean) as string[];

if (keys.length === 0) {
  console.warn("⚠️ No Groq API keys found. Add them in environment variables.");
}

let currentKeyIndex = 0;

function getNextKey(): string {
  if (keys.length === 0) {
    throw new Error("No Groq API keys configured");
  }
  const key = keys[currentKeyIndex];
  currentKeyIndex = (currentKeyIndex + 1) % keys.length;
  return key;
}

export function createGroqClient() {
  const apiKey = getNextKey();
  return new Groq({ apiKey });
}

export async function groqChatCompletion(
  params: {
    model: string;
    messages: any[];
    temperature?: number;
    max_tokens?: number;
    stream?: boolean;
  },
  maxRetries = keys.length || 1
) {
  let lastError: any;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const client = createGroqClient();

    try {
      const response = await client.chat.completions.create({
        ...params,
        stream: false,
      });
      return response;
    } catch (error: any) {
      lastError = error;

      const isRateLimit =
        error?.status === 429 ||
        error?.error?.code === "rate_limit_exceeded" ||
        error?.message?.toLowerCase()?.includes("rate limit") ||
        error?.message?.toLowerCase()?.includes("quota") ||
        error?.message?.toLowerCase()?.includes("too many requests");

      if (isRateLimit) {
        console.warn(
          `[Groq] Key #${currentKeyIndex} hit limit → switching to next key...`
        );
        continue;
      }

      throw error;
    }
  }

  throw lastError || new Error("All Groq keys exhausted");
}
