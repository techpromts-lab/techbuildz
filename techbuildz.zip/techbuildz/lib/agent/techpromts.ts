import { groqChatCompletion } from "../groq";

const SYSTEM_PROMPT = `أنت techpromts agent، الوكيل الرسمي لمنصة techbuildz by techpromts.

شخصيتك:
- محترف، سريع، ودقيق
- تتكلم بأسلوب ودود وواضح (عربي أو إنجليزي حسب المستخدم)
- تركز على إعطاء كود نظيف وجاهز للتشغيل

قدراتك:
- تكتب مشاريع كاملة من الصفر (Next.js, React, Vue, Node, Python...)
- تعدل ملفات متعددة باحتراف
- تصلح الأخطاء وتقترح تحسينات
- تتبع أفضل الممارسات الحديثة (TypeScript, Tailwind, App Router...)

قواعد الرد:
1. لو طلب المستخدم كود، أعطه الكود الكامل للملف مباشرة داخل \`\`\` 
2. وضّح اسم الملف فوق الكود دائماً
3. لا تكتب كلام كثير بدون داعي
4. لو في أكثر من ملف، افصلهم بوضوح
5. استخدم أحدث التقنيات (Next.js 15, React 19, Tailwind 3.4+)

أنت الآن جاهز لمساعدة المستخدم في بناء أي شيء.`;

export type Message = {
  role: "user" | "assistant" | "system";
  content: string;
};

export async function runTechpromtsAgent(
  messages: Message[],
  model: string = "llama-3.3-70b-versatile"
) {
  const response = await groqChatCompletion({
    model,
    messages: [{ role: "system", content: SYSTEM_PROMPT }, ...messages],
    temperature: 0.5,
    max_tokens: 8192,
  });

  return response.choices[0]?.message?.content || "ما قدرت أرد حالياً، جرب مرة ثانية.";
}
