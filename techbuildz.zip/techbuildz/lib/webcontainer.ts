import { WebContainer } from "@webcontainer/api";

let webcontainerInstance: WebContainer | null = null;

export async function getWebContainer(): Promise<WebContainer> {
  if (webcontainerInstance) {
    return webcontainerInstance;
  }

  webcontainerInstance = await WebContainer.boot({
    coep: "require-corp",
  });

  return webcontainerInstance;
}

export async function resetWebContainer() {
  if (webcontainerInstance) {
    // WebContainer doesn't have a direct destroy, we just null it
    webcontainerInstance = null;
  }
}
