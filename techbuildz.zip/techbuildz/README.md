# techbuildz by techpromts

Vibe coding platform powered by AI — **techpromts agent**

## Features

- AI Agent (techpromts agent) powered by Groq
- Automatic API Key Rotation (5 Groq keys)
- Live Preview with WebContainers
- Multiple environments: Next.js, React+Vite, Node.js, HTML
- Monaco Editor
- File Tree
- Export to GitHub
- Beautiful dark premium UI
- Settings panel (environment + model)

## Setup

1. Clone the repo
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env.local` and add your keys:
   ```
   GROQ_API_KEY_1=gsk_...
   GROQ_API_KEY_2=gsk_...
   GROQ_API_KEY_3=gsk_...
   GROQ_API_KEY_4=gsk_...
   GROQ_API_KEY_5=gsk_...
   GITHUB_TOKEN=ghp_...   # optional
   ```
4. Run:
   ```bash
   npm run dev
   ```

## Deploy on Vercel

1. Push to GitHub
2. Import project in Vercel
3. Add the environment variables
4. Deploy

## Notes

- WebContainers requires special COOP/COEP headers (already configured in `next.config.ts`)
- For production GitHub export, add a `GITHUB_TOKEN` with `repo` scope
- The agent automatically rotates between the 5 Groq keys when rate limited

---

Made with ❤️ by techpromts
